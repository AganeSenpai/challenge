﻿namespace Challenge.DTO;
public class SinistroDTO
{
    public int Id { get; set; }
    public string? Descricao { get; set; }
    public string? Status { get; set; }
}

