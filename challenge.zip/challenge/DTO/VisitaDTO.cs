﻿namespace Challenge.DTO;
public class VisitaDTO
{
    public int Id { get; set; }
    public DateTime Data { get; set; }
    public int UsuarioId { get; set; }
    public int SinistroId { get; set; }
}

