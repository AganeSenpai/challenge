﻿using challenge.Models;
using Microsoft.EntityFrameworkCore;

namespace challenge.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Usuario> Usuarios { get; set; }
    public DbSet<Visita> Visitas { get; set; }
    public DbSet<Sinistro> Sinistros { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Usuario>().ToTable("Usuarios");
        modelBuilder.Entity<Visita>().ToTable("Visitas");
        modelBuilder.Entity<Sinistro>().ToTable("Sinistros");
    }
}
