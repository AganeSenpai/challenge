﻿using challenge.Models;

namespace challenge.Models;

public class Sinistro
{
    public int Id { get; set; }
    public string? Descricao { get; set; }
    public ICollection<Visita>? Visitas { get; set; }
}
