﻿using challenge.Models;

namespace challenge.Models;

public class Visita
{
    public int Id { get; set; }
    public DateTime Data { get; set; }
    public int UsuarioId { get; set; }
    public Usuario? Usuario { get; set; } // Relacionamento com Usuario
    public int SinistroId { get; set; }
    public Sinistro? Sinistro { get; set; } // Relacionamento com Sinistro
}
