using Microsoft.EntityFrameworkCore;
using challenge.Data;

var builder = WebApplication.CreateBuilder(args);

// Adicionar DbContext com o uso do SQL Server
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Adicionar os controladores (API)
builder.Services.AddControllers();

var app = builder.Build();

// Configurar a aplica��o para usar controladores
app.MapControllers();

// Rodar a aplica��o
app.Run();
